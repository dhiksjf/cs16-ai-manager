# CE Public HTTP Bridge + Cloudflare Tunnel

This document is the implementation guide for the public bridge that exposes
the Cheat Engine MCP server to AI agents on the open Internet. It is meant
to be read by another AI agent (or a human) that needs to understand the
architecture, the security model, and the way to extend it.

If you only want to *use* the bridge from a remote machine, the README has a
shorter quick-start. This file is the long-form reference.

## Why this exists

The v12 bridge is three processes -- AI client → Python MCP server → Lua in
Cheat Engine. Both transports that ship today (Windows named pipe, TCP
relay) require the AI client to be on a network the bridge trusts. That is
fine for the IDE-embedded agent (Cursor, Claude Code, Codex, ...). It is
limiting for hosted agents -- cloud sandboxes, Codespaces, remote servers --
where the AI cannot open a port to the user's machine and does not have a
trusted route into the user's LAN.

The public bridge adds a fourth process and one extra hop:

```
[Remote AI agent]
     │ HTTPS + Bearer <ACCESS_CODE>
     ▼
[Cloudflare Edge]   ← this hop is on Cloudflare's network, not yours
     │ QUIC / HTTP2 (tunnel)
     ▼
[cloudflared]       ← runs on the user's machine
     │ 127.0.0.1:9877
     ▼
[ce_public_bridge.py]  ← HTTP server, validates the bearer, rate-limits
     │ length-prefixed JSON-RPC (same wire format as the pipe)
     ▼
[\\.\pipe\CE_MCP_Bridge_v99]  ← unchanged
     ▼
[ce_mcp_bridge.lua]   ← unchanged
```

The Lua side and the pipe protocol are unchanged. The public bridge is a
shim that lives *in front* of the pipe and is the only thing that ever
talks to the open Internet.

## Component map

| File | Role | Runs on |
|------|------|---------|
| `MCP_Server/ce_public_bridge.py` | HTTP server. Auth, rate limit, JSON-RPC over HTTP. | Windows (where CE lives). Can be on a Linux host if you also use the TCP relay. |
| `MCP_Server/cloudflare_tunnel.py` | Locates or downloads `cloudflared`, spawns it, parses the public URL. | Same machine as the bridge. |
| `MCP_Server/ce_public_client.py` | Synchronous Python client. Stdlib `urllib` only. | Anywhere the agent runs. |
| `MCP_Server/start_public_bridge.sh` / `.bat` | One-shot launcher that runs both bridge and tunnel and tears them down together. | Same machine as the bridge. |
| `MCP_Server/test_public_bridge.py` | Hermetic smoke test (no real CE, no internet). | Anywhere. |

## Wire format

The bridge re-uses the v12 framing verbatim. There is no new wire format to
learn. The HTTP layer only changes two things:

1. A `Content-Length`-bounded JSON body wraps the existing JSON-RPC envelope.
2. Every non-`GET /` and non-`GET /ping` request must carry
   `Authorization: Bearer <code>`.

Two POST endpoints are equivalent:

```
POST /rpc                  POST /call/<method>
{                              {
  "jsonrpc": "2.0",               "address": "0x401000",
  "method": "read_memory",        "size": 16
  "params": { ... },            }
  "id": 1
}
```

Both return the same envelope:

```
{
  "ok": true,
  "result": { "success": true, ... },
  "id": 1
}
```

Errors are normalized to a top-level `ok: false` with a string `error`. The
Lua-side error envelope (when CE itself returns `{ success: false, error: ... }`)
is preserved in `result` and `ok` is set to `false` at the bridge level.

## Security model

The threat model is "an attacker on the public Internet who can reach the
Cloudflare URL." A few things follow from that:

* **The Bearer code is the only credential.** It is checked in constant
  time (`hmac.compare_digest`) on every request. The fingerprint printed
  in the banner is a sha256 prefix so operators can log it without leaking
  the secret.
* **Rate limit per source IP.** Default 600 req/min/token-bucket. A
  runaway agent cannot saturate the Lua side.
* **No state is kept on disk by the bridge.** Logs go to stderr only.
* **CORS is permissive** because the bridge is meant to be called from
  browser-embedded agents too. This does not weaken the security model
  because every data endpoint still requires Bearer auth.
* **Loopback bind by default.** The bridge only binds to `0.0.0.0` if you
  explicitly pass `--host 0.0.0.0`, and it warns when you do. The
  Cloudflare Tunnel works fine against a loopback bind because the tunnel
  itself is the trust boundary.

There is no CSRF protection, but the only way to make a state-changing
call is to present the Bearer code in `Authorization`. CSRF requires a
browser to attach a cookie; we use Bearer only, so the attack is
infeasible.

## How to extend

Most extensions are just "expose one more method." The bridge has a
`KNOWN_METHODS` list used by `/tools` for capability discovery. Adding to
that list is purely documentary -- the Lua side is the source of truth
and the bridge forwards any method name. If you add a real new tool in
`ce_mcp_bridge.lua` and `mcp_cheatengine.py`, also:

1. Add the snake_case name to `KNOWN_METHODS` in
   `MCP_Server/ce_public_bridge.py` so `/tools` advertises it.
2. If the method has parameters that need normalization, add a convenience
   wrapper to `MCP_Server/ce_public_client.py`.

If you add a new HTTP endpoint (say `/v2/rpc` for streaming responses),
follow the existing pattern:

* Add a `do_<verb>` method on `BridgeHTTPHandler`.
* Gate it with `self._require_auth()` and `self._enforce_rate()`.
* Use `_json_response` or `_text_response` to keep response shape uniform.

If you need to add middleware (auth proxy, request signing, ...), insert
it between `cloudflared` and `ce_public_bridge.py` rather than inside the
bridge -- the bridge assumes the request is already past the auth layer.

## Operations

### Log locations

* `ce_public_bridge.py` writes to stderr only. Default level INFO. Use
  `--log-level DEBUG` for per-request bodies.
* `cloudflared` writes to its own stdout/stderr. Pass `--log-file
  <path>` to `cloudflare_tunnel.py` to keep them in a file.
* `start_public_bridge.sh` does not redirect; the bridge's banner and the
  tunnel's URL go straight to the terminal.

### Restarting

The public bridge is stateless -- killing and restarting it does not
affect the CE side beyond a brief window where `/ping` returns
`ce_unreachable` (502). The Lua side is unchanged.

The Cloudflare quick tunnel URL rotates every restart. If you need a
stable URL, run a named tunnel (`--named <NAME>`) and use
`cloudflared tunnel login` once.

### Hitting the rate limit

`429 Too Many Requests` is the response. The body contains the configured
`limit_per_minute`. If you need more headroom, raise it with `--rate
2400` (40 req/sec) on the bridge side, or distribute agents across more
source IPs (Cloudflare preserves the source IP in the tunnel, so this is
the real throttle, not a per-Cloudflare-edge throttle).

### Shutting down

`Ctrl+C` in the terminal running `ce_public_bridge.py` or
`start_public_bridge.sh` initiates a clean shutdown. The bridge closes
all in-flight pipe connections and stops the HTTP server. The tunnel
subprocess is killed by the launcher script.

## Testing

`test_public_bridge.py` covers the bridge and the client in-process:

* Bearer-auth negative cases (missing header, wrong token)
* JSON-RPC envelope forwarding and round-trip
* REST shortcut
* CE-side error propagation
* Batch ordering
* 400 on invalid JSON
* `/tools` shape
* Rate-limit 429 path
* Client-side edge cases (missing URL/code)

The test stubs the transport so it does not need a running Cheat Engine
or a real `cloudflared`. Run with:

```
python MCP_Server/test_public_bridge.py
```

There is no end-to-end test against a real tunnel because that needs
Cloudflare account credentials and a real CE process. Use the
`--print-url` mode of `cloudflare_tunnel.py` for a manual check.

## Why not just expose the pipe directly?

A few options were considered:

* **Direct TCP** (`socat`-style). Works, but it bypasses any auth layer
  and exposes the wire protocol verbatim. An attacker who can guess
  `\\.\pipe\CE_MCP_Bridge_v99` can drive the bridge without any
  credentials. The HTTP layer adds Bearer auth, rate limiting, and
  friendlier semantics.
* **WireGuard tunnel**. Too much operator overhead for a one-off remote
  agent job. Cloudflare is zero-config.
* **ngrok**. Paid for fixed URLs; otherwise URL rotates on every restart
  just like `cloudflared`. No advantage over the cloudflared path.
* **A pure `cloudflared` over the pipe.** `cloudflared` does not speak
  the v12 length-prefixed framing, so we would have to add an HTTP layer
  anyway. Adding it as a Python process we control also lets us put
  auth in the same place as the protocol shim.

The HTTP shim is the minimal change that gets us remote access without
giving up any of the v12 wire format.
