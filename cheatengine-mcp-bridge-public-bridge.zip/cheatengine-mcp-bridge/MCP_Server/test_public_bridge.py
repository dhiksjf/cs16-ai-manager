#!/usr/bin/env python3
"""Smoke test for the public CE bridge.

This exercises ``ce_public_bridge.py`` and ``ce_public_client.py`` without
requiring a real Cheat Engine or a real Cloudflare Tunnel. We start the HTTP
server with an in-memory transport that echoes back canned responses, then
point the Python client at it and assert every endpoint behaves as documented.

Run::

    python MCP_Server/test_public_bridge.py
"""

from __future__ import annotations

import json
import os
import socket
import struct
import sys
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import ce_public_bridge as cpb  # noqa: E402
import ce_public_client as cpc  # noqa: E402


# ---------------------------------------------------------------------------
#  In-memory transport that pretends to be the Cheat Engine pipe.
# ---------------------------------------------------------------------------


class _FakeTransport:
    """Implements the subset of the transport API that ``ce_public_bridge``
    uses. Returns canned responses for known methods and records the last
    call so tests can assert what was forwarded."""

    def __init__(self) -> None:
        from collections import deque
        self.calls: list[tuple[str, dict]] = []
        self._queue: "deque[dict]" = deque()
        self._lock = threading.Lock()
        self._default = {
            "jsonrpc": "2.0", "id": None,
            "result": {"success": True, "echo": True},
        }

    def queue_response(self, response: dict) -> None:
        with self._lock:
            self._queue.append(response)

    def queue_responses(self, responses) -> None:
        with self._lock:
            for r in responses:
                self._queue.append(r)

    @property
    def connected(self) -> bool:
        return True

    def connect(self) -> bool:
        return True

    def exchange(self, payload: bytes) -> bytes:
        envelope = json.loads(payload.decode("utf-8"))
        self.calls.append((envelope["method"], envelope.get("params") or {}))
        with self._lock:
            if self._queue:
                response = self._queue.popleft()
            else:
                response = dict(self._default)
        # Always echo the request id so callers can correlate.
        if "id" not in response or response["id"] is None:
            response["id"] = envelope["id"]
        return json.dumps(response).encode("utf-8")

    def close(self) -> None:
        return None


def _start_test_server(transport: _FakeTransport, access_code: str = "TEST-CODE-1234",
                       rate: int = 0) -> tuple[ThreadingHTTPServer, str]:
    state = cpb._BridgeState(
        transport=transport,
        access_code=access_code,
        code_fingerprint=cpb._fingerprint(access_code),
    )

    class _Handler(cpb.BridgeHTTPHandler):
        pass

    _Handler.state = state
    server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    server.rate_per_min = rate  # type: ignore[attr-defined]
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
    thread.start()
    return server, f"http://127.0.0.1:{server.server_address[1]}"


def _wait_ready(server: ThreadingHTTPServer, timeout: float = 2.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection(server.server_address, timeout=0.2):
                return True
        except OSError:
            time.sleep(0.05)
    return False


# ---------------------------------------------------------------------------
#  Tests
# ---------------------------------------------------------------------------


class BridgeHTTPTests(unittest.TestCase):
    """End-to-end tests for the HTTP server with a fake CE transport."""

    def setUp(self) -> None:
        self.transport = _FakeTransport()
        self.server, self.url = _start_test_server(self.transport)
        self.assertTrue(_wait_ready(self.server))
        self.client = cpc.CEClient(base_url=self.url, access_code="TEST-CODE-1234")

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()

    # --- authentication ---

    def test_root_banner_no_auth(self) -> None:
        env = self.client.version()
        self.assertTrue(env["ok"])
        # The banner lives at GET /, not /version -- do a raw call to be sure.
        import urllib.request
        with urllib.request.urlopen(self.url + "/", timeout=2) as r:
            data = json.loads(r.read().decode("utf-8"))
        self.assertEqual(data["service"], "cheatengine-mcp-public-bridge")
        self.assertEqual(data["wire_version"], cpb.WIRE_PROTOCOL_VERSION)
        self.assertEqual(data["auth"]["fingerprint"], cpb._fingerprint("TEST-CODE-1234"))

    def test_unknown_token_is_rejected(self) -> None:
        # /ping is intentionally unauthenticated so the test uses an
        # auth-protected endpoint to verify the bearer check fires.
        import urllib.request
        req = urllib.request.Request(
            self.url + "/call/ping", data=b"{}", method="POST",
            headers={"Authorization": "Bearer WRONG",
                     "Content-Type": "application/json"},
        )
        try:
            urllib.request.urlopen(req, timeout=2)
        except urllib.error.HTTPError as exc:
            self.assertEqual(exc.code, 401)
            body = json.loads(exc.read().decode("utf-8"))
            self.assertEqual(body["error"], "invalid_or_missing_access_code")
        else:
            self.fail("Expected 401 with wrong Bearer token")

    def test_missing_header_is_rejected(self) -> None:
        import urllib.request
        req = urllib.request.Request(self.url + "/call/ping", data=b"{}", method="POST",
                                     headers={"Content-Type": "application/json"})
        try:
            urllib.request.urlopen(req, timeout=2)
        except urllib.error.HTTPError as exc:
            self.assertEqual(exc.code, 401)
        else:
            self.fail("Expected 401 without Authorization header")

    # --- core call paths ---

    def test_jsonrpc_envelope_is_forwarded(self) -> None:
        self.transport.queue_response({
            "jsonrpc": "2.0", "id": 1,
            "result": {"success": True, "version": "12.0.0", "message": "ok"},
        })
        result = self.client.ping()
        self.assertTrue(result["ok"])
        self.assertEqual(result["ce"]["version"], "12.0.0")
        # The HTTP server unwraps the JSON-RPC envelope, so the wire-level
        # method name is the only thing recorded in ``transport.calls``.
        self.assertEqual(self.transport.calls[-1][0], "ping")

    def test_rest_shortcut(self) -> None:
        self.transport.queue_response({
            "jsonrpc": "2.0", "id": 1,
            "result": {"success": True, "pid": 4242, "name": "notepad.exe"},
        })
        info = self.client.call_rest("get_process_info")
        self.assertEqual(info["pid"], 4242)
        self.assertEqual(self.transport.calls[-1][0], "get_process_info")
        self.assertEqual(self.transport.calls[-1][1], {})

    def test_ce_error_propagates(self) -> None:
        self.transport.queue_response({
            "jsonrpc": "2.0", "id": 1,
            "error": {"code": -32601, "message": "Method not found"},
        })
        with self.assertRaises(cpc.CEBridgeError) as ctx:
            self.client.call("nope_does_not_exist")
        self.assertIn("Method not found", str(ctx.exception))

    def test_convenience_methods(self) -> None:
        self.transport.queue_response({
            "jsonrpc": "2.0", "id": 1,
            "result": {"success": True, "value": 1234, "type": "dword"},
        })
        value = self.client.read_integer("0x401000", "dword")
        self.assertEqual(value["value"], 1234)
        self.assertEqual(self.transport.calls[-1][0], "read_integer")
        self.assertEqual(self.transport.calls[-1][1]["type"], "dword")

    def test_batch_runs_in_order(self) -> None:
        self.transport.queue_responses([
            {"jsonrpc": "2.0", "id": 1, "result": {"success": True, "n": 1}},
            {"jsonrpc": "2.0", "id": 2, "result": {"success": True, "n": 2}},
        ])
        results = self.client.batch([
            {"method": "ping", "params": {}},
            {"method": "get_process_info", "params": {}},
        ])
        self.assertEqual([r["result"]["n"] for r in results], [1, 2])

    def test_bad_json_returns_400(self) -> None:
        import urllib.request
        req = urllib.request.Request(
            self.url + "/rpc", data=b"not json", method="POST",
            headers={
                "Authorization": "Bearer TEST-CODE-1234",
                "Content-Type": "application/json",
            },
        )
        try:
            urllib.request.urlopen(req, timeout=2)
        except urllib.error.HTTPError as exc:
            self.assertEqual(exc.code, 400)
            payload = json.loads(exc.read().decode("utf-8"))
            self.assertEqual(payload["error"], "invalid_json")
        else:
            self.fail("Expected 400 for invalid JSON")

    def test_methods_list_is_well_formed(self) -> None:
        tools = self.client.tools()
        # We curate a subset of the ~180 commands the bridge exposes.
        # The list is kept in sync with ce_mcp_bridge.lua's commandHandlers
        # for the most-used verbs; the bridge still forwards any method
        # name to Lua, so missing entries here are not a runtime error.
        self.assertGreater(tools["count"], 50)
        # Sanity check a few of the methods we expect to find.
        for expected in ("read_memory", "scan_all", "set_breakpoint",
                         "disassemble", "ping", "get_process_info"):
            self.assertIn(expected, tools["methods"])
        # And that /tools itself is reachable without auth.
        import urllib.request
        with urllib.request.urlopen(self.url + "/tools", timeout=2) as r:
            payload = json.loads(r.read().decode("utf-8"))
        self.assertTrue(payload["ok"])

    # --- rate limiting ---

    def test_rate_limit_returns_429(self) -> None:
        # Spin up a server with a tiny rate-limit so we can blow through it
        # without spamming the loopback.
        self.server.shutdown()
        self.server.server_close()
        self.transport = _FakeTransport()
        self.server, self.url = _start_test_server(self.transport, rate=2)
        self.assertTrue(_wait_ready(self.server))
        self.client = cpc.CEClient(base_url=self.url, access_code="TEST-CODE-1234")
        # Two requests per minute -> the first two pass, the third 429s.
        # We use the unauthenticated /ping endpoint with a mock auth, so we
        # also need to bump the rate for auth calls; 2 is still enough.
        # NOTE: ping does not require auth, but it shares the rate limiter
        # with authed calls. Therefore hitting /ping three times rapidly
        # should still trip the limiter.
        for _ in range(2):
            self.client.ping()
        with self.assertRaises(cpc.CEBridgeError) as ctx:
            self.client.ping()
        self.assertEqual(ctx.exception.status, 429)
        self.assertEqual(ctx.exception.code, "rate_limited")


class ClientEdgeCaseTests(unittest.TestCase):
    def test_missing_url_raises(self) -> None:
        # Clear the env override so the test is hermetic.
        os.environ.pop("CE_BRIDGE_URL", None)
        os.environ.pop("CE_BRIDGE_CODE", None)
        with self.assertRaises(cpc.CEBridgeError):
            cpc.CEClient(base_url="", access_code="")
        with self.assertRaises(cpc.CEBridgeError):
            cpc.CEClient(base_url="https://example.com", access_code="")


if __name__ == "__main__":
    unittest.main(verbosity=2)
