@echo off
REM One-shot launcher: start the CE public bridge AND the Cloudflare Tunnel
REM side by side. Prints the public URL and access code on stdout so it can
REM be piped into a chat / shell history / credential vault.
REM
REM Usage:
REM   start_public_bridge.bat
REM   start_public_bridge.bat --port 9999
REM   start_public_bridge.bat --code-file C:\path\to\code.txt
REM   start_public_bridge.bat --named my-tunnel
REM
REM Stop both with Ctrl+C -- the script traps it and tears down both children.

setlocal EnableExtensions EnableDelayedExpansion

set "SCRIPT_DIR=%~dp0"
pushd "%SCRIPT_DIR%"

set "BRIDGE_ARGS="
set "TUNNEL_ARGS="

:parse_args
if "%~1"=="" goto :end_parse
if /I "%~1"=="--port"        ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --port %2" & set "TUNNEL_ARGS=!TUNNEL_ARGS! --port %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--host"        ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --host %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--transport"   ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --transport %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--pipe"        ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --pipe %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--ce-host"     ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --ce-host %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--ce-port"     ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --ce-port %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--code"        ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --code %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--code-file"   ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --code-file %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--rate"        ( set "BRIDGE_ARGS=!BRIDGE_ARGS! --rate %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--named"       ( set "TUNNEL_ARGS=!TUNNEL_ARGS! --named %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--cloudflared" ( set "TUNNEL_ARGS=!TUNNEL_ARGS! --cloudflared %2" & shift & shift & goto :parse_args )
if /I "%~1"=="--log-file"    ( set "TUNNEL_ARGS=!TUNNEL_ARGS! --log-file %2" & shift & shift & goto :parse_args )
if /I "%~1"=="/h" goto :usage
if /I "%~1"=="--help" goto :usage
echo Unknown argument: %~1
popd
exit /b 2

:usage
echo Usage: %~nx0 [--port N] [--host IP] [--transport pipe|tcp] [--pipe NAME] [--ce-host IP] [--ce-port N] [--code CODE] [--code-file PATH] [--rate N] [--named NAME] [--cloudflared PATH] [--log-file PATH]
popd
exit /b 0

:end_parse

echo [start] Launching ce_public_bridge.py%BRIDGE_ARGS%
start "CE Public Bridge" /B cmd /c "python ce_public_bridge.py%BRIDGE_ARGS%"

REM Give the bridge a moment to bind the port and print the access code.
ping -n 3 127.0.0.1 >nul

echo [start] Launching cloudflare_tunnel.py%TUNNEL_ARGS%
start "CE Cloudflare Tunnel" /B cmd /c "python cloudflare_tunnel.py --print-url%TUNNEL_ARGS%"

echo.
echo Press Ctrl+C in this window to stop both.
pause
popd
endlocal
