"""Lightweight Python client for the CE public HTTP bridge.

Use this from any AI agent that wants to drive Cheat Engine from the open
Internet. The client speaks plain HTTP+JSON, so it works with stdlib only --
no MCP SDK, no pywin32, no Windows. The only requirement is ``urllib``
from the standard library.

Quick start
===========

::

    from ce_public_client import CEClient

    client = CEClient(
        base_url="https://random-words.trycloudflare.com",
        access_code="YOUR-BEARER-CODE",
    )
    print(client.ping())                  # health check
    print(client.get_process_info())      # raw CE call
    print(client.read_memory("0x100", 16))

The same client is safe to use concurrently from multiple threads and is
deliberately chatty on errors -- it raises ``CEBridgeError`` with a ``code``
attribute that matches the JSON-RPC error envelopes used elsewhere in the
project.

Environment variables
=====================

``CE_BRIDGE_URL`` and ``CE_BRIDGE_CODE`` are read as fallbacks. This is the
expected way to configure the client for an AI agent that wants to keep
secrets out of source code.

::

    export CE_BRIDGE_URL="https://random-words.trycloudflare.com"
    export CE_BRIDGE_CODE="ABCDEFGH-IJKLMNOP-QRSTUVWX-YZ234567"
    python agent.py
"""

from __future__ import annotations

import json
import os
import threading
import time
import urllib.error
import urllib.request
from typing import Any, Dict, Iterable, List, Optional, Sequence, Union


# ---------------------------------------------------------------------------
#  Exceptions
# ---------------------------------------------------------------------------


class CEBridgeError(RuntimeError):
    """Base error raised by ``CEClient`` on protocol or transport failures."""

    def __init__(self, message: str, *, code: Optional[str] = None,
                 status: Optional[int] = None, payload: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.status = status
        self.payload = payload

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return (f"CEBridgeError({self.args[0]!r}, "
                f"code={self.code!r}, status={self.status!r})")


# ---------------------------------------------------------------------------
#  Client
# ---------------------------------------------------------------------------


_DEFAULT_TIMEOUT = 30.0
_DEFAULT_RETRIES = 2
_RETRYABLE_HTTP = {429, 500, 502, 503, 504}


class CEClient:
    """Synchronous client for the public CE bridge.

    Parameters
    ----------
    base_url:
        Public URL of the bridge, e.g. ``https://<random>.trycloudflare.com``.
        Trailing slashes are stripped.
    access_code:
        Bearer access code. Must be supplied unless ``CE_BRIDGE_CODE`` is set
        in the environment.
    timeout:
        Per-request timeout in seconds (default: 30).
    retries:
        Number of additional attempts on retryable transport errors. The
        client always makes ``retries + 1`` attempts at most.
    extra_headers:
        Optional mapping merged into every request. Useful for tagging
        traffic when many agents share a tunnel.
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        access_code: Optional[str] = None,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
        retries: int = _DEFAULT_RETRIES,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> None:
        resolved_url = (base_url or os.environ.get("CE_BRIDGE_URL") or "").strip()
        if not resolved_url:
            raise CEBridgeError(
                "CE_BRIDGE_URL is not set. Pass base_url= or export CE_BRIDGE_URL."
            )
        self.base_url = resolved_url.rstrip("/")
        self.access_code = (access_code if access_code is not None
                            else os.environ.get("CE_BRIDGE_CODE") or "").strip()
        if not self.access_code:
            raise CEBridgeError(
                "Access code is empty. Pass access_code= or export CE_BRIDGE_CODE."
            )
        self.timeout = float(timeout)
        self.retries = max(0, int(retries))
        self._extra_headers = dict(extra_headers or {})
        self._seq_lock = threading.Lock()
        self._seq = 0

    # ------------------------------------------------------------------
    # HTTP plumbing
    # ------------------------------------------------------------------

    def _next_id(self) -> int:
        with self._seq_lock:
            self._seq += 1
            return self._seq

    def _request(self, method: str, path: str, body: Any = None,
                 *, allow_retry: bool = True) -> Dict[str, Any]:
        url = f"{self.base_url}{path}"
        payload_bytes: Optional[bytes] = None
        if body is not None:
            payload_bytes = json.dumps(body).encode("utf-8")
        attempts = self.retries + 1 if allow_retry else 1
        last_exc: Optional[Exception] = None
        for attempt in range(attempts):
            req = urllib.request.Request(
                url, data=payload_bytes, method=method,
                headers={
                    "Authorization": f"Bearer {self.access_code}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "User-Agent": "ce_public_client/1.0",
                    **self._extra_headers,
                },
            )
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    raw = resp.read()
                    status = resp.status
            except urllib.error.HTTPError as exc:
                status = exc.code
                raw = exc.read() if hasattr(exc, "read") else b""
                if status not in _RETRYABLE_HTTP or attempt == attempts - 1:
                    return self._raise_http(status, raw, exc)
                last_exc = exc
                time.sleep(0.25 * (attempt + 1))
                continue
            except urllib.error.URLError as exc:
                if attempt == attempts - 1:
                    raise CEBridgeError(
                        f"Network error calling {url}: {exc.reason}",
                        code="NETWORK_ERROR",
                    ) from exc
                last_exc = exc
                time.sleep(0.25 * (attempt + 1))
                continue
            except TimeoutError as exc:
                if attempt == attempts - 1:
                    raise CEBridgeError(
                        f"Timeout after {self.timeout:g}s calling {url}",
                        code="TIMEOUT",
                    ) from exc
                last_exc = exc
                time.sleep(0.25 * (attempt + 1))
                continue

            try:
                return json.loads(raw.decode("utf-8")) if raw else {}
            except json.JSONDecodeError as exc:
                raise CEBridgeError(
                    f"Non-JSON response from {url}: {raw[:200]!r}",
                    code="INVALID_JSON",
                    status=status,
                ) from exc
        # Unreachable, but mypy likes the explicit raise.
        raise CEBridgeError(f"Exhausted retries: {last_exc}", code="RETRY_EXHAUSTED")

    def _raise_http(self, status: int, raw: bytes,
                    exc: Optional[Exception] = None) -> "Any":
        message = f"HTTP {status}"
        code: Optional[str] = None
        payload: Any = None
        if raw:
            try:
                payload = json.loads(raw.decode("utf-8"))
                if isinstance(payload, dict):
                    code = payload.get("error") or payload.get("code")
                    message = payload.get("error") or payload.get("message") or message
            except json.JSONDecodeError:
                payload = raw[:200]
        raise CEBridgeError(message, code=code, status=status, payload=payload) from exc

    # ------------------------------------------------------------------
    # High-level helpers
    # ------------------------------------------------------------------

    def call(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Call a single CE method and return its ``result`` field.

        Raises ``CEBridgeError`` if the bridge returns an error envelope.
        """
        envelope = self._request("POST", "/rpc", {
            "jsonrpc": "2.0",
            "method": method,
            "params": params or {},
            "id": self._next_id(),
        })
        if not envelope.get("ok", True):
            raise CEBridgeError(
                envelope.get("error", "unknown error"),
                code=envelope.get("error"),
                payload=envelope,
            )
        return envelope.get("result")

    def call_rest(self, method: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """Call a single CE method via the REST shortcut endpoint."""
        envelope = self._request("POST", f"/call/{method}", params or {})
        if not envelope.get("ok", True):
            raise CEBridgeError(
                envelope.get("error", "unknown error"),
                code=envelope.get("error"),
                payload=envelope,
            )
        return envelope.get("result")

    def batch(self, calls: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Fire a batch of calls in order. Each item is ``{"method": ..., "params": ...}``.

        The bridge currently processes requests sequentially, so this
        preserves ordering. The returned list is aligned with the input.
        """
        out: List[Dict[str, Any]] = []
        for item in calls:
            method = item["method"]
            params = item.get("params") or {}
            try:
                result = self.call(method, params)
                out.append({"method": method, "ok": True, "result": result})
            except CEBridgeError as exc:
                out.append({"method": method, "ok": False, "error": str(exc),
                            "code": exc.code})
        return out

    def ping(self) -> Dict[str, Any]:
        """Health probe. Returns the raw envelope including CE version info."""
        return self._request("GET", "/ping")

    def version(self) -> Dict[str, Any]:
        return self._request("GET", "/version")

    def tools(self) -> Dict[str, Any]:
        return self._request("GET", "/tools")

    # ------------------------------------------------------------------
    # Convenience wrappers around the most common CE methods.
    # Keep the set small: the bridge exposes ~180 methods, and adding
    # them all here is not a value-add. Call ``self.call("...", {...})``
    # for the long tail.
    # ------------------------------------------------------------------

    def get_process_info(self) -> Any:
        return self.call("get_process_info")

    def attach(self, process_name_or_pid: Union[str, int]) -> Any:
        """Open a process by name or PID. ``process_name_or_pid`` can be a
        string like ``"notepad.exe"`` or an integer PID."""
        if isinstance(process_name_or_pid, int):
            return self.call("open_process", {"pid": process_name_or_pid})
        return self.call("open_process", {"name": process_name_or_pid})

    def read_memory(self, address: Union[str, int], size: int) -> Any:
        return self.call("read_memory", {"address": str(address), "size": int(size)})

    def read_integer(self, address: Union[str, int], type_: str = "dword") -> Any:
        return self.call("read_integer", {"address": str(address), "type": type_})

    def read_string(self, address: Union[str, int], max_length: int = 256,
                    wide: bool = False, encoding: str = "utf8") -> Any:
        return self.call("read_string", {
            "address": str(address), "max_length": max_length,
            "wide": wide, "encoding": encoding,
        })

    def read_pointer_chain(self, base: Union[str, int],
                           offsets: Sequence[int]) -> Any:
        return self.call("read_pointer_chain", {
            "base": str(base), "offsets": [int(o) for o in offsets],
        })

    def write_memory(self, address: Union[str, int], data: Union[bytes, str]) -> Any:
        """Write ``data`` (bytes or hex string) to ``address``."""
        if isinstance(data, bytes):
            data = data.hex()
        return self.call("write_memory", {"address": str(address), "data": data})

    def write_integer(self, address: Union[str, int], value: int,
                      type_: str = "dword") -> Any:
        return self.call("write_integer", {
            "address": str(address), "value": int(value), "type": type_,
        })

    def scan_all(self, value: Union[str, int, float],
                 scan_type: str = "exact", protection: str = "+W-C") -> Any:
        return self.call("scan_all", {
            "value": value, "type": scan_type, "protection": protection,
        })

    def next_scan(self, value: Union[str, int, float], scan_type: str = "exact") -> Any:
        return self.call("next_scan", {"value": value, "scan_type": scan_type})

    def get_scan_results(self, offset: int = 0, limit: int = 100) -> Any:
        return self.call("get_scan_results", {"offset": offset, "limit": limit})

    def disassemble(self, address: Union[str, int], size: int = 64) -> Any:
        return self.call("disassemble", {"address": str(address), "size": size})

    def analyze_function(self, address: Union[str, int]) -> Any:
        return self.call("analyze_function", {"address": str(address)})

    def find_what_writes(self, address: Union[str, int]) -> Any:
        return self.call("find_what_writes", {"address": str(address)})

    def find_what_reads(self, address: Union[str, int]) -> Any:
        return self.call("find_what_reads", {"address": str(address)})

    def set_breakpoint(self, address: Union[str, int]) -> Any:
        return self.call("set_breakpoint", {"address": str(address)})

    def remove_breakpoint(self, address: Union[str, int]) -> Any:
        return self.call("remove_breakpoint", {"address": str(address)})

    # ------------------------------------------------------------------
    # Dunder for ergonomic agent usage.
    # ------------------------------------------------------------------

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return f"CEClient(base_url={self.base_url!r}, code=***)"


# ---------------------------------------------------------------------------
#  CLI smoke test
# ---------------------------------------------------------------------------


def _cli() -> int:
    import argparse
    p = argparse.ArgumentParser(
        prog="ce_public_client",
        description="Quick smoke test for the CE public bridge from a remote machine.",
    )
    p.add_argument("--url", default=os.environ.get("CE_BRIDGE_URL"),
                   help="Bridge URL (default: $CE_BRIDGE_URL).")
    p.add_argument("--code", default=os.environ.get("CE_BRIDGE_CODE"),
                   help="Access code (default: $CE_BRIDGE_CODE).")
    p.add_argument("--method", default="ping",
                   help="Method to call (default: ping).")
    p.add_argument("--params", default="{}",
                   help="JSON params (default: {}).")
    args = p.parse_args()
    client = CEClient(base_url=args.url, access_code=args.code)
    if args.method in {"ping", "version", "tools"}:
        result = getattr(client, args.method)()
    else:
        params = json.loads(args.params)
        result = client.call(args.method, params)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
