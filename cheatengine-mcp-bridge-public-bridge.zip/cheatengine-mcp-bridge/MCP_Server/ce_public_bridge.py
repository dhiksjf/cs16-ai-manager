#!/usr/bin/env python3
r"""HTTP-to-named-pipe bridge that exposes the Cheat Engine MCP bridge to the
public Internet via a Cloudflare Tunnel, protected by a Bearer access code.

Run on the same Windows machine that runs Cheat Engine. Listens on a local
loopback port (default 127.0.0.1:9877) and accepts JSON-RPC requests that are
forwarded, in the same length-prefixed framing as the native pipe, to
``\\.\pipe\CE_MCP_Bridge_v99``.

Pair this with ``cloudflare_tunnel.py`` (or any other Cloudflare Tunnel
launcher) to make the bridge reachable from the open Internet without opening
a firewall port. The Bearer access code is the only thing standing between
the public Internet and full Cheat Engine control of the host process --
treat it like an API key.

Wire protocol
=============

This server is the public side of the bridge. It speaks the same wire format
as ``mcp_cheatengine.py`` so anything that talks to the pipe can talk to it.

*  ``POST /rpc``  -- JSON-RPC envelope.
    Request body::

        {"jsonrpc":"2.0","method":"ping","params":{},"id":1}

    Response body is the same envelope returned by the Lua side.

*  ``POST /call/<method>``  -- REST shortcut. Body is the ``params`` object.
    Response body is the ``result`` field of the JSON-RPC response.

*  ``GET  /ping``  -- Health probe. Returns ``{"ok":true,...}``.

*  ``GET  /tools``  -- Returns a list of method names the bridge knows about.
    Used by AI agents to enumerate capabilities without crawling the source.

*  ``GET  /``  -- Returns a short banner with the bridge version, the wire
    protocol version, the transport in use, and a list of endpoints.

All non-``GET /`` and non-``GET /ping`` endpoints require an
``Authorization: Bearer <ACCESS_CODE>`` header. Tokens are compared in
constant time.

Usage
=====

::

    # Default: random access code, loopback on port 9877
    python ce_public_bridge.py

    # Custom access code, custom port
    python ce_public_bridge.py --code "swordfish-cherry-tango" --port 9877

    # Custom access code read from a file
    python ce_public_bridge.py --code-file ~/.ce_bridge_code

    # Use TCP relay instead of named pipe (when CE runs in a VM/container)
    python ce_public_bridge.py --transport tcp --host 192.168.1.10 --port 9876

    # Bind to all interfaces (do not combine with a public tunnel without
    # an access code)
    python ce_public_bridge.py --host 0.0.0.0
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import logging
import os
import secrets
import signal
import socket
import struct
import sys
import threading
import time
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Optional, Tuple

# Bridge wire-protocol version -- must match ce_mcp_bridge.lua PIPE_NAME suffix.
WIRE_PROTOCOL_VERSION = 99
BRIDGE_APP_VERSION = "12.0.0+public"

PIPE_NAME_DEFAULT = r"\\.\pipe\CE_MCP_Bridge_v99"
TCP_HOST_DEFAULT = "127.0.0.1"
TCP_PORT_DEFAULT = 9876
HTTP_HOST_DEFAULT = "127.0.0.1"
HTTP_PORT_DEFAULT = 9877
MAX_FRAME_BYTES = 32 * 1024 * 1024  # 32 MiB cap per response frame.

LOG = logging.getLogger("ce_public_bridge")

# ---------------------------------------------------------------------------
#  Transport clients (mirror mcp_cheatengine.py)
# ---------------------------------------------------------------------------


class TransportError(ConnectionError):
    """Raised when a transport-level error occurs (pipe closed, TCP reset)."""


class _PipeTransport:
    """Windows named-pipe transport. Uses the same length-prefixed framing as
    the MCP server."""

    def __init__(self) -> None:
        self.handle: Optional[Any] = None
        self._lock = threading.Lock()
        try:
            import win32file  # type: ignore
            import pywintypes  # type: ignore
        except ImportError as exc:  # pragma: no cover - Windows-only
            raise RuntimeError(
                "Named-pipe transport requires Windows with pywin32 installed."
            ) from exc
        self._win32file = win32file
        self._pywintypes = pywintypes
        self._pipe_name = PIPE_NAME_DEFAULT

    @property
    def connected(self) -> bool:
        return self.handle is not None

    @property
    def pipe_name(self) -> str:
        return self._pipe_name

    def set_pipe_name(self, name: str) -> None:
        self._pipe_name = name

    def connect(self) -> bool:
        try:
            self.handle = self._win32file.CreateFile(
                self._pipe_name,
                self._win32file.GENERIC_READ | self._win32file.GENERIC_WRITE,
                0,
                None,
                self._win32file.OPEN_EXISTING,
                0,
                None,
            )
            return True
        except self._pywintypes.error:
            self.handle = None
            return False

    def _read_exact(self, size: int) -> bytes:
        chunks = []
        remaining = size
        while remaining > 0:
            try:
                chunk = self._win32file.ReadFile(self.handle, remaining)[1]
            except self._pywintypes.error as exc:
                raise TransportError(f"Pipe read failed: {exc}") from exc
            if not chunk:
                raise TransportError("Connection closed while reading pipe.")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def exchange(self, payload: bytes) -> bytes:
        if not self.connected and not self.connect():
            raise TransportError(f"Cannot open pipe {self._pipe_name!r}.")
        header = struct.pack("<I", len(payload))
        try:
            self._win32file.WriteFile(self.handle, header)
            self._win32file.WriteFile(self.handle, payload)
        except self._pywintypes.error as exc:
            self.close()
            raise TransportError(f"Pipe write failed: {exc}") from exc
        resp_header = self._read_exact(4)
        resp_len = struct.unpack("<I", resp_header)[0]
        if resp_len > MAX_FRAME_BYTES:
            raise TransportError(f"Response too large: {resp_len} bytes.")
        return self._read_exact(resp_len)

    def close(self) -> None:
        if self.handle is not None:
            try:
                self._win32file.CloseHandle(self.handle)
            except Exception:  # noqa: BLE001 - best effort
                pass
            self.handle = None


class _TcpTransport:
    """TCP relay transport. Same length-prefixed framing as the pipe."""

    def __init__(self, host: str, port: int) -> None:
        self.host = host
        self.port = port
        self.sock: Optional[socket.socket] = None

    @property
    def connected(self) -> bool:
        return self.sock is not None

    def connect(self) -> bool:
        try:
            self.sock = socket.create_connection((self.host, self.port), timeout=10.0)
            self.sock.settimeout(None)
            return True
        except OSError:
            self.close()
            return False

    def _read_exact(self, size: int) -> bytes:
        assert self.sock is not None
        chunks = []
        remaining = size
        while remaining > 0:
            chunk = self.sock.recv(remaining)
            if not chunk:
                raise TransportError("Connection closed while reading TCP relay.")
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    def exchange(self, payload: bytes) -> bytes:
        if not self.connected and not self.connect():
            raise TransportError(f"Cannot connect to TCP relay {self.host}:{self.port}.")
        assert self.sock is not None
        self.sock.sendall(struct.pack("<I", len(payload)) + payload)
        resp_header = self._read_exact(4)
        resp_len = struct.unpack("<I", resp_header)[0]
        if resp_len > MAX_FRAME_BYTES:
            raise TransportError(f"Response too large: {resp_len} bytes.")
        return self._read_exact(resp_len)

    def close(self) -> None:
        if self.sock is not None:
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None


def _make_transport(transport: str, host: str, port: int, pipe_name: str):
    if transport == "tcp":
        return _TcpTransport(host, port)
    if transport == "pipe":
        t = _PipeTransport()
        t.set_pipe_name(pipe_name)
        return t
    raise ValueError(f"Unknown transport: {transport!r}")


# ---------------------------------------------------------------------------
#  Method catalog (used by /tools and for client-side autocompletion hints).
#  Keep in sync with ce_mcp_bridge.lua commandHandlers and mcp_cheatengine.py
#  tool registrations. The list is not enforced server-side; unknown methods
#  are still forwarded and the Lua side returns the canonical error.
# ---------------------------------------------------------------------------

KNOWN_METHODS = [
    # Process / modules
    "get_process_info", "open_process", "get_process_list", "create_process",
    "pause_process", "unpause_process", "enum_modules", "get_thread_list",
    "get_symbol_address", "get_address_info", "get_rtti_classname",
    "enable_windows_symbols",
    # Memory read
    "read_memory", "read_integer", "read_string", "read_pointer",
    "read_pointer_chain", "analyze_pointer_access", "validate_pointer_chains",
    "checksum_memory",
    # Scanning
    "scan_all", "next_scan", "get_scan_results", "reset_scan", "aob_scan",
    # Memory write / allocation
    "write_memory", "write_integer", "write_string", "allocate_memory",
    "free_memory", "set_memory_protection", "full_access",
    # Debugging
    "set_breakpoint", "set_data_breakpoint", "remove_breakpoint",
    "start_dbvm_watch", "stop_dbvm_watch", "dbk_get_cr3",
    "read_process_memory_cr3", "capture_registers", "capture_stack",
    # Disassembly / analysis
    "disassemble", "analyze_function", "dissect_structure", "find_references",
    "find_call_references", "find_what_writes", "find_what_reads",
    # Symbols
    "register_symbol", "get_symbol_info", "list_symbols",
    # Code injection
    "inject_dll", "execute_code", "execute_method", "assemble_instruction",
    "compile_c_code", "generate_api_hook_script",
    # Window / GUI
    "find_window", "send_window_message", "enum_windows",
    # Input automation
    "get_pixel", "is_key_pressed", "do_key_press", "send_text",
    # Cheat table
    "load_table", "save_table", "get_address_list",
    # Misc
    "ping", "get_version", "get_capabilities",
    "run_command", "shell_execute",  # gated by CE_MCP_ALLOW_SHELL
]


# ---------------------------------------------------------------------------
#  Request handler
# ---------------------------------------------------------------------------


class _BridgeState:
    """Process-wide state shared by the HTTP handler."""

    def __init__(self, transport, access_code: str, code_fingerprint: str) -> None:
        self.transport = transport
        self.access_code = access_code
        self.code_fingerprint = code_fingerprint
        self._lock = threading.Lock()
        self._rpc_seq = 0
        # Per-IP rate limit state. Simple token bucket; tuned for protecting
        # CE from runaway remote agents rather than against real DDoS.
        self._buckets: Dict[str, Tuple[float, float]] = {}

    def next_rpc_id(self) -> int:
        with self._lock:
            self._rpc_seq += 1
            return self._rpc_seq

    def check_rate_limit(self, ip: str, rate_per_min: int) -> bool:
        """Return True if the request is allowed, False if it should be 429'd."""
        if rate_per_min <= 0:
            return True
        now = time.monotonic()
        with self._lock:
            tokens, last = self._buckets.get(ip, (float(rate_per_min), now))
            elapsed = now - last
            tokens = min(float(rate_per_min), tokens + elapsed * (rate_per_min / 60.0))
            if tokens < 1.0:
                self._buckets[ip] = (tokens, now)
                return False
            tokens -= 1.0
            self._buckets[ip] = (tokens, now)
            return True

    def forward(self, method: str, params: Any, rpc_id: Any = None) -> Dict[str, Any]:
        """Send a single JSON-RPC request through the wire transport.

        Returns a JSON-RPC shaped dict. We always include ``id`` so the client
        can correlate multi-call batches (the server processes them in order).
        """
        if params is None:
            params = {}
        request = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": rpc_id if rpc_id is not None else self.next_rpc_id(),
        }
        body = json.dumps(request).encode("utf-8")
        max_attempts = 2
        last_err: Optional[Exception] = None
        for _ in range(max_attempts):
            try:
                resp = self.transport.exchange(body)
                return json.loads(resp.decode("utf-8"))
            except (TransportError, OSError) as exc:
                last_err = exc
                try:
                    self.transport.close()
                except Exception:  # noqa: BLE001
                    pass
        raise ConnectionError(
            f"Transport failed after {max_attempts} attempts: {last_err}"
        )


def _check_bearer(headers, expected: str) -> bool:
    """Constant-time Bearer token check."""
    auth_header = headers.get("Authorization", "")
    if not auth_header.lower().startswith("bearer "):
        return False
    presented = auth_header[7:].strip()
    if not presented or not expected:
        return False
    return hmac.compare_digest(presented.encode("utf-8"), expected.encode("utf-8"))


def _read_body(handler: BaseHTTPRequestHandler) -> bytes:
    length_raw = handler.headers.get("Content-Length", "0")
    try:
        length = int(length_raw)
    except ValueError:
        raise ValueError(f"Invalid Content-Length: {length_raw!r}")
    if length < 0 or length > MAX_FRAME_BYTES:
        raise ValueError(f"Content-Length out of range: {length}")
    if length == 0:
        return b""
    return handler.rfile.read(length)


def _json_response(handler: BaseHTTPRequestHandler, status: int, payload: dict) -> None:
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("X-Bridge-Version", BRIDGE_APP_VERSION)
    handler.send_header("X-Bridge-Wire", f"v{WIRE_PROTOCOL_VERSION}")
    handler.end_headers()
    handler.wfile.write(body)


def _text_response(handler: BaseHTTPRequestHandler, status: int, body: bytes,
                   content_type: str = "text/plain; charset=utf-8") -> None:
    handler.send_response(status)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(body)


class BridgeHTTPHandler(BaseHTTPRequestHandler):
    server_version = f"CEPublicBridge/{BRIDGE_APP_VERSION}"
    state: _BridgeState  # injected by the server

    # ------------------------------------------------------------------
    # Plumbing
    # ------------------------------------------------------------------

    def log_message(self, format: str, *args) -> None:  # noqa: A002 - stdlib API
        LOG.info("%s - %s", self.address_string(), format % args)

    def _client_ip(self) -> str:
        # If a reverse proxy is in front of this server, use the forwarded
        # header. We deliberately do not trust X-Forwarded-For when bound
        # to the public Internet -- only honor it when the immediate peer
        # is loopback. This protects the rate limiter from being bypassed
        # by spoofing the header.
        peer = self.client_address[0] if self.client_address else "unknown"
        if peer in {"127.0.0.1", "::1"}:
            forwarded = self.headers.get("X-Forwarded-For", "")
            if forwarded:
                return forwarded.split(",")[0].strip()
        return peer

    def _require_auth(self) -> bool:
        if _check_bearer(self.headers, self.state.access_code):
            return True
        _json_response(self, HTTPStatus.UNAUTHORIZED, {
            "ok": False,
            "error": "invalid_or_missing_access_code",
            "hint": "Send 'Authorization: Bearer <ACCESS_CODE>'.",
        })
        return False

    def _enforce_rate(self) -> bool:
        rate = int(self.server.rate_per_min)  # type: ignore[attr-defined]
        if not self.state.check_rate_limit(self._client_ip(), rate):
            _json_response(self, HTTPStatus.TOO_MANY_REQUESTS, {
                "ok": False,
                "error": "rate_limited",
                "limit_per_minute": rate,
            })
            return False
        return True

    # ------------------------------------------------------------------
    # Routes
    # ------------------------------------------------------------------

    def do_GET(self) -> None:  # noqa: N802 - stdlib API
        path = self.path.split("?", 1)[0]
        if path == "/":
            return self._handle_root()
        if path == "/ping":
            return self._handle_ping()
        if path == "/version":
            return _json_response(self, HTTPStatus.OK, {
                "ok": True,
                "bridge_version": BRIDGE_APP_VERSION,
                "wire_version": WIRE_PROTOCOL_VERSION,
            })
        if path == "/tools":
            return self._handle_tools()
        if path == "/healthz":
            return _json_response(self, HTTPStatus.OK, {"ok": True})
        _json_response(self, HTTPStatus.NOT_FOUND, {"ok": False, "error": "not_found", "path": path})

    def do_POST(self) -> None:  # noqa: N802 - stdlib API
        path = self.path.split("?", 1)[0]
        if not self._require_auth():
            return
        if not self._enforce_rate():
            return
        if path == "/rpc":
            return self._handle_rpc()
        if path.startswith("/call/"):
            method = path[len("/call/"):]
            return self._handle_call(method)
        _json_response(self, HTTPStatus.NOT_FOUND, {"ok": False, "error": "not_found", "path": path})

    def do_OPTIONS(self) -> None:  # noqa: N802 - stdlib API
        # Permissive CORS for browser-based AIs. Bearer auth still enforced on
        # the actual call, so this only relaxes the preflight, not the data.
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
        self.send_header("Access-Control-Max-Age", "86400")
        self.end_headers()

    # ------------------------------------------------------------------
    # Handlers
    # ------------------------------------------------------------------

    def _handle_root(self) -> None:
        _json_response(self, HTTPStatus.OK, {
            "ok": True,
            "service": "cheatengine-mcp-public-bridge",
            "bridge_version": BRIDGE_APP_VERSION,
            "wire_version": WIRE_PROTOCOL_VERSION,
            "transport": "tcp" if isinstance(self.state.transport, _TcpTransport) else "named_pipe",
            "endpoints": {
                "GET /":         "this banner",
                "GET /ping":     "health probe (no auth)",
                "GET /version":  "version info (no auth)",
                "GET /tools":    "known method names (no auth)",
                "GET /healthz":  "L7 health check (no auth)",
                "POST /rpc":     "JSON-RPC over HTTP (auth required)",
                "POST /call/<method>": "REST shortcut (auth required)",
            },
            "auth": {
                "type": "Bearer",
                "fingerprint": self.state.code_fingerprint,
                "hint": "Pass the access code in 'Authorization: Bearer <code>'.",
            },
        })

    def _handle_ping(self) -> None:
        if not self._enforce_rate():
            return
        # Ping is useful enough that we expose it without auth, but rate-limit
        # it like every other request.
        try:
            result = self.state.forward("ping", {})
        except (TransportError, ConnectionError) as exc:
            return _json_response(self, HTTPStatus.BAD_GATEWAY, {
                "ok": False,
                "error": "ce_unreachable",
                "detail": str(exc),
            })
        # The Lua side returns { success, version, message, ... } -- surface it
        # alongside our own envelope so clients can see both.
        _json_response(self, HTTPStatus.OK, {
            "ok": True,
            "ce": result.get("result", result),
        })

    def _handle_tools(self) -> None:
        _json_response(self, HTTPStatus.OK, {
            "ok": True,
            "count": len(KNOWN_METHODS),
            "methods": KNOWN_METHODS,
        })

    def _handle_rpc(self) -> None:
        try:
            body = _read_body(self)
        except ValueError as exc:
            return _json_response(self, HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(exc)})
        try:
            envelope = json.loads(body.decode("utf-8")) if body else {}
        except json.JSONDecodeError as exc:
            return _json_response(self, HTTPStatus.BAD_REQUEST, {
                "ok": False,
                "error": "invalid_json",
                "detail": str(exc),
            })
        if not isinstance(envelope, dict):
            return _json_response(self, HTTPStatus.BAD_REQUEST, {
                "ok": False, "error": "expected_object",
            })
        method = envelope.get("method")
        if not isinstance(method, str) or not method:
            return _json_response(self, HTTPStatus.BAD_REQUEST, {
                "ok": False, "error": "missing_method",
            })
        params = envelope.get("params", {}) or {}
        if not isinstance(params, dict):
            return _json_response(self, HTTPStatus.BAD_REQUEST, {
                "ok": False, "error": "params_must_be_object",
            })
        rpc_id = envelope.get("id", self.state.next_rpc_id())
        return self._dispatch(method, params, rpc_id)

    def _handle_call(self, method: str) -> None:
        if not method or not all(c.isalnum() or c == "_" for c in method):
            return _json_response(self, HTTPStatus.BAD_REQUEST, {
                "ok": False, "error": "invalid_method_name", "method": method,
            })
        try:
            body = _read_body(self)
        except ValueError as exc:
            return _json_response(self, HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(exc)})
        params: Any = {}
        if body:
            try:
                params = json.loads(body.decode("utf-8"))
            except json.JSONDecodeError as exc:
                return _json_response(self, HTTPStatus.BAD_REQUEST, {
                    "ok": False, "error": "invalid_json", "detail": str(exc),
                })
        if params is None:
            params = {}
        if not isinstance(params, dict):
            return _json_response(self, HTTPStatus.BAD_REQUEST, {
                "ok": False, "error": "params_must_be_object",
            })
        return self._dispatch(method, params, self.state.next_rpc_id())

    def _dispatch(self, method: str, params: Dict[str, Any], rpc_id: Any) -> None:
        try:
            response = self.state.forward(method, params, rpc_id)
        except (TransportError, ConnectionError) as exc:
            return _json_response(self, HTTPStatus.BAD_GATEWAY, {
                "ok": False,
                "error": "ce_unreachable",
                "detail": str(exc),
                "id": rpc_id,
            })
        if "error" in response:
            return _json_response(self, HTTPStatus.OK, {
                "ok": False,
                "error": response["error"],
                "id": response.get("id", rpc_id),
            })
        return _json_response(self, HTTPStatus.OK, {
            "ok": True,
            "result": response.get("result"),
            "id": response.get("id", rpc_id),
        })


# ---------------------------------------------------------------------------
#  Server bootstrap
# ---------------------------------------------------------------------------


def _generate_access_code() -> str:
    """Generate a memorable access code: 4 words + checksum digit."""
    # 16 bytes of entropy, base32 -> 32 chars; format as 4 groups of 8.
    raw = secrets.token_bytes(16)
    encoded = base64.b32encode(raw).decode("ascii").rstrip("=")
    grouped = "-".join(encoded[i:i + 8] for i in range(0, len(encoded), 8))
    return grouped


def _fingerprint(code: str) -> str:
    """Short, non-reversible identifier for the access code (for /tools etc)."""
    digest = hashlib.sha256(code.encode("utf-8")).hexdigest()
    return f"sha256:{digest[:12]}"


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ce_public_bridge",
        description="HTTP bridge that proxies JSON-RPC to the Cheat Engine pipe.",
    )
    p.add_argument("--host", default=HTTP_HOST_DEFAULT,
                   help=f"HTTP bind address (default: {HTTP_HOST_DEFAULT}; "
                        "0.0.0.0 binds all interfaces, do not use without auth).")
    p.add_argument("--port", type=int, default=HTTP_PORT_DEFAULT,
                   help=f"HTTP bind port (default: {HTTP_PORT_DEFAULT}).")
    p.add_argument("--transport", choices=("pipe", "tcp"), default="pipe",
                   help="Transport to Cheat Engine (default: pipe).")
    p.add_argument("--pipe", default=PIPE_NAME_DEFAULT,
                   help=f"Named pipe path (default: {PIPE_NAME_DEFAULT}).")
    p.add_argument("--ce-host", default=TCP_HOST_DEFAULT,
                   help=f"CE TCP relay host when --transport=tcp (default: {TCP_HOST_DEFAULT}).")
    p.add_argument("--ce-port", type=int, default=TCP_PORT_DEFAULT,
                   help=f"CE TCP relay port when --transport=tcp (default: {TCP_PORT_DEFAULT}).")
    p.add_argument("--code", default=None,
                   help="Access code (Bearer token). If omitted a random one is generated.")
    p.add_argument("--code-file", default=None,
                   help="Read the access code from this file (whitespace stripped).")
    p.add_argument("--rate", type=int, default=600,
                   help="Per-IP requests per minute (default: 600; 0 = unlimited).")
    p.add_argument("--log-level", default="INFO",
                   choices=("DEBUG", "INFO", "WARNING", "ERROR"))
    return p


def _resolve_access_code(args: argparse.Namespace) -> str:
    if args.code and args.code_file:
        raise SystemExit("Pass either --code or --code-file, not both.")
    if args.code_file:
        with open(args.code_file, "r", encoding="utf-8") as fh:
            return fh.read().strip()
    if args.code:
        return args.code.strip()
    return _generate_access_code()


def main() -> int:
    args = _build_argparser().parse_args()
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(levelname)s] %(message)s",
        stream=sys.stderr,
    )

    access_code = _resolve_access_code(args)
    if not access_code:
        LOG.error("Access code resolved to empty string; refusing to start.")
        return 2

    try:
        transport = _make_transport(args.transport, args.ce_host, args.ce_port, args.pipe)
    except RuntimeError as exc:
        LOG.error("%s", exc)
        return 3

    state = _BridgeState(
        transport=transport,
        access_code=access_code,
        code_fingerprint=_fingerprint(access_code),
    )

    server = ThreadingHTTPServer((args.host, args.port), BridgeHTTPHandler)
    server.rate_per_min = args.rate  # type: ignore[attr-defined]
    BridgeHTTPHandler.state = state

    stop_event = threading.Event()

    def _on_signal(signum, _frame):  # noqa: ANN001 - signal API
        LOG.info("Received signal %d, shutting down.", signum)
        stop_event.set()
        # ThreadingHTTPServer.shutdown must run from a different thread.
        threading.Thread(target=server.shutdown, daemon=True).start()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _on_signal)
        except (ValueError, OSError):
            pass  # not the main thread, or unsupported on this OS

    pipe_desc = (f"named pipe {args.pipe}"
                 if args.transport == "pipe"
                 else f"TCP relay {args.ce_host}:{args.ce_port}")
    LOG.info("CE Public Bridge %s starting.", BRIDGE_APP_VERSION)
    LOG.info("  HTTP:   http://%s:%d", args.host, args.port)
    LOG.info("  CE:     %s", pipe_desc)
    LOG.info("  Auth:   Bearer (fingerprint=%s)", state.code_fingerprint)
    LOG.info("  Rate:   %d req/min/IP (0 = unlimited)", args.rate)
    if args.host in {"0.0.0.0", "::"}:
        LOG.warning("Binding to all interfaces -- anyone on the local network can reach the bridge.")
    if args.host not in {"127.0.0.1", "::1", "localhost"}:
        LOG.warning("Not bound to loopback. Do NOT run without a Cloudflare Tunnel or access code in front of it.")

    print(
        "\n" + "=" * 72 + "\n"
        "  CE Public Bridge is up.\n"
        f"  HTTP     : http://{args.host}:{args.port}\n"
        f"  Access   : {access_code}\n"
        f"  Fingerprint: {state.code_fingerprint}\n"
        "  Next step: launch 'python cloudflare_tunnel.py' to expose it publicly.\n"
        + "=" * 72 + "\n",
        file=sys.stderr, flush=True,
    )

    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        transport.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
