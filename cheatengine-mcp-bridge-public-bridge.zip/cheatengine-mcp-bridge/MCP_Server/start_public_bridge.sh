#!/usr/bin/env bash
# One-shot launcher: start the CE public bridge AND the Cloudflare Tunnel
# side by side. Prints the public URL and access code on stdout so it can
# be piped into a chat / shell history / credential vault.
#
# Usage:
#   ./start_public_bridge.sh                       # defaults (loopback:9877, named pipe)
#   ./start_public_bridge.sh --port 9999           # custom port
#   ./start_public_bridge.sh --named my-tunnel     # named tunnel (fixed URL)
#   ./start_public_bridge.sh --code-file ./code.txt
#
# This is intentionally a thin shell wrapper. Anything non-trivial lives in
# the Python modules so it works the same on Windows (start_public_bridge.bat).

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

BRIDGE_ARGS=()
TUNNEL_ARGS=()

while [[ $# -gt 0 ]]; do
    case "$1" in
        --port)        BRIDGE_ARGS+=(--port "$2"); TUNNEL_ARGS+=(--port "$2"); shift 2 ;;
        --host)        BRIDGE_ARGS+=(--host "$2"); shift 2 ;;
        --transport)   BRIDGE_ARGS+=(--transport "$2"); shift 2 ;;
        --pipe)        BRIDGE_ARGS+=(--pipe "$2"); shift 2 ;;
        --ce-host)     BRIDGE_ARGS+=(--ce-host "$2"); shift 2 ;;
        --ce-port)     BRIDGE_ARGS+=(--ce-port "$2"); shift 2 ;;
        --code)        BRIDGE_ARGS+=(--code "$2"); shift 2 ;;
        --code-file)   BRIDGE_ARGS+=(--code-file "$2"); shift 2 ;;
        --rate)        BRIDGE_ARGS+=(--rate "$2"); shift 2 ;;
        --named)       TUNNEL_ARGS+=(--named "$2"); shift 2 ;;
        --cloudflared) TUNNEL_ARGS+=(--cloudflared "$2"); shift 2 ;;
        --log-file)    TUNNEL_ARGS+=(--log-file "$2"); shift 2 ;;
        -h|--help)
            echo "Usage: $0 [bridge args] -- [tunnel args]"
            echo "Bridge args: --port --host --transport --pipe --ce-host --ce-port --code --code-file --rate"
            echo "Tunnel args: --named --cloudflared --log-file"
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            exit 2
            ;;
    esac
done

PID_DIR="${TMPDIR:-/tmp}/ce_public_bridge"
mkdir -p "$PID_DIR"
BRIDGE_PID_FILE="$PID_DIR/bridge.pid"
TUNNEL_PID_FILE="$PID_DIR/tunnel.pid"

cleanup() {
    echo
    echo "[start] Shutting down ..."
    if [[ -f "$TUNNEL_PID_FILE" ]]; then
        kill "$(cat "$TUNNEL_PID_FILE")" 2>/dev/null || true
        rm -f "$TUNNEL_PID_FILE"
    fi
    if [[ -f "$BRIDGE_PID_FILE" ]]; then
        kill "$(cat "$BRIDGE_PID_FILE")" 2>/dev/null || true
        rm -f "$BRIDGE_PID_FILE"
    fi
}
trap cleanup EXIT INT TERM

echo "[start] Launching ce_public_bridge.py ${BRIDGE_ARGS[*]}"
python3 ce_public_bridge.py "${BRIDGE_ARGS[@]}" &
BRIDGE_PID=$!
echo "$BRIDGE_PID" > "$BRIDGE_PID_FILE"

# Give the bridge a moment to bind the port and print the access code.
sleep 2

# Make sure the bridge is still alive.
if ! kill -0 "$BRIDGE_PID" 2>/dev/null; then
    echo "[start] Bridge exited before tunnel could start. See log above." >&2
    exit 1
fi

echo "[start] Launching cloudflare_tunnel.py ${TUNNEL_ARGS[*]}"
python3 cloudflare_tunnel.py --print-url "${TUNNEL_ARGS[@]}" &
TUNNEL_PID=$!
echo "$TUNNEL_PID" > "$TUNNEL_PID_FILE"

# Wait for either child to exit.
wait -n "$BRIDGE_PID" "$TUNNEL_PID"
echo "[start] One of the children exited; tearing down."
