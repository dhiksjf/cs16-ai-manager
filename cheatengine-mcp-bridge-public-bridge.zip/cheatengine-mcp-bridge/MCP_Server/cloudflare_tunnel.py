#!/usr/bin/env python3
r"""Cloudflare Tunnel launcher for the Cheat Engine MCP public bridge.

This script locates (or downloads) the ``cloudflared`` binary and starts a
public HTTPS tunnel that forwards traffic to the local ``ce_public_bridge.py``
HTTP server. The result is a ``https://<random>.trycloudflare.com`` URL that
any AI agent on the open Internet can use -- provided they also have the
Bearer access code printed by ``ce_public_bridge.py``.

Quick tunnel vs named tunnel
============================

Quick tunnel (the default) needs no Cloudflare account. The URL is
``*.trycloudflare.com`` and changes every time ``cloudflared`` restarts.

Named tunnel gives you a stable URL on a domain you own. Run
``cloudflared tunnel login`` once in this directory, then pass
``--named <NAME>``.

Usage
=====

::

    # Easiest: assumes ce_public_bridge.py is already running on 127.0.0.1:9877
    python cloudflare_tunnel.py

    # Custom local port
    python cloudflare_tunnel.py --port 9877

    # Use an existing cloudflared binary instead of downloading one
    python cloudflare_tunnel.py --cloudflared /usr/local/bin/cloudflared

    # Stable URL on your own domain (requires prior `cloudflared tunnel login`)
    python cloudflare_tunnel.py --named my-ce-bridge
"""

from __future__ import annotations

import argparse
import os
import platform
import re
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Optional

LOG_PREFIX = "[cf-tunnel]"

# ---------------------------------------------------------------------------
#  cloudflared discovery / download
# ---------------------------------------------------------------------------

# Maps (system, machine) -> (asset suffix, archive format).
# Source: https://github.com/cloudflare/cloudflared/releases
_CF_ASSETS = {
    ("Windows", "AMD64"): ("cloudflared-windows-amd64.exe", "exe"),
    ("Windows", "x86_64"): ("cloudflared-windows-amd64.exe", "exe"),
    ("Linux", "AMD64"):    ("cloudflared-linux-amd64",      "tgz"),
    ("Linux", "x86_64"):   ("cloudflared-linux-amd64",      "tgz"),
    ("Linux", "arm64"):    ("cloudflared-linux-arm64",      "tgz"),
    ("Linux", "aarch64"):  ("cloudflared-linux-arm64",      "tgz"),
    ("Darwin", "AMD64"):   ("cloudflared-darwin-amd64.tgz", "tgz"),
    ("Darwin", "x86_64"):  ("cloudflared-darwin-amd64.tgz", "tgz"),
    ("Darwin", "arm64"):   ("cloudflared-darwin-arm64.tgz", "tgz"),
    ("Darwin", "aarch64"): ("cloudflared-darwin-arm64.tgz", "tgz"),
}

# Public Cloudflare release endpoint. We use the "latest" redirect so the
# download always tracks the most recent stable build.
_CF_RELEASE_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/{asset}"

DEFAULT_LOCAL_DIR = Path(__file__).resolve().parent / "cloudflared"
DEFAULT_PORT = 9877


def _log(msg: str) -> None:
    print(f"{LOG_PREFIX} {msg}", file=sys.stderr, flush=True)


def _detect_target() -> tuple[str, str]:
    system = platform.system()
    machine = platform.machine()
    if (system, machine) not in _CF_ASSETS:
        # Try common aliases.
        alias = {"x86_64": "AMD64", "aarch64": "arm64"}.get(machine, machine)
        if (system, alias) in _CF_ASSETS:
            machine = alias
    if (system, machine) not in _CF_ASSETS:
        raise RuntimeError(
            f"Unsupported platform: {system}/{machine}. "
            "Download cloudflared manually from "
            "https://github.com/cloudflare/cloudflared/releases and pass --cloudflared."
        )
    return system, machine


def _candidate_paths() -> list[Path]:
    """Places we will look for an existing cloudflared binary."""
    candidates: list[Path] = []
    env_path = os.environ.get("CLOUDFLARED")
    if env_path:
        candidates.append(Path(env_path))
    local = DEFAULT_LOCAL_DIR / ("cloudflared.exe" if os.name == "nt" else "cloudflared")
    candidates.append(local)
    on_path = shutil.which("cloudflared") or shutil.which("cloudflared.exe")
    if on_path:
        candidates.append(Path(on_path))
    return candidates


def find_cloudflared(explicit: Optional[str] = None) -> Optional[Path]:
    if explicit:
        p = Path(explicit)
        if p.is_file():
            return p
        raise FileNotFoundError(f"--cloudflared path does not exist: {explicit}")
    for p in _candidate_paths():
        if p.is_file():
            _log(f"Using existing cloudflared at {p}")
            return p
    return None


def download_cloudflared(target: Path) -> Path:
    """Download and extract a cloudflared binary into ``target.parent``."""
    system, machine = _detect_target()
    asset, fmt = _CF_ASSETS[(system, machine)]
    url = _CF_RELEASE_URL.format(asset=asset)
    target.parent.mkdir(parents=True, exist_ok=True)
    _log(f"Downloading {asset} from {url} ...")
    with tempfile.NamedTemporaryFile(
        suffix=".tmp",
        delete=False,
        dir=str(target.parent),
    ) as tmp:
        tmp_path = Path(tmp.name)
    try:
        with urllib.request.urlopen(url, timeout=120) as resp, open(tmp_path, "wb") as out:
            shutil.copyfileobj(resp, out)
        if fmt == "tgz":
            _log("Extracting tarball ...")
            with tarfile.open(tmp_path, "r:gz") as tar:
                member = next((m for m in tar.getmembers() if m.name.endswith("cloudflared")), None)
                if member is None:
                    raise RuntimeError("cloudflared binary not found in archive.")
                with tar.extractfile(member) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
        elif fmt == "exe":
            shutil.move(str(tmp_path), str(target))
        else:
            raise RuntimeError(f"Unknown archive format: {fmt}")
    finally:
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass

    if os.name != "nt":
        target.chmod(target.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    _log(f"Saved cloudflared to {target}")
    return target


def ensure_cloudflared(explicit: Optional[str] = None) -> Path:
    found = find_cloudflared(explicit)
    if found is not None:
        return found
    binary_name = "cloudflared.exe" if os.name == "nt" else "cloudflared"
    target = DEFAULT_LOCAL_DIR / binary_name
    if target.is_file():
        _log(f"Using cached cloudflared at {target}")
        return target
    try:
        return download_cloudflared(target)
    except (urllib.error.URLError, OSError) as exc:
        raise RuntimeError(
            "Could not download cloudflared automatically "
            f"({exc}). Install it manually and pass --cloudflared."
        ) from exc


# ---------------------------------------------------------------------------
#  Tunnel runner
# ---------------------------------------------------------------------------

_URL_RE = re.compile(r"https?://[a-zA-Z0-9\-]+\.trycloudflare\.com")


def run_tunnel(
    cloudflared: Path,
    local_url: str,
    named: Optional[str] = None,
    extra_args: Optional[list[str]] = None,
    log_path: Optional[Path] = None,
) -> subprocess.Popen:
    if named:
        args = [str(cloudflared), "tunnel", "run", named]
    else:
        args = [
            str(cloudflared), "tunnel",
            "--no-autoupdate",
            "--url", local_url,
        ]
        # On networks that block UDP/443, fall back to http2 over TCP/443.
        # This is harmless on the open Internet; it just makes cloudflared
        # work in more locked-down environments.
        args.extend(["--protocol", "http2"])
    if extra_args:
        args.extend(extra_args)
    _log("Executing: " + " ".join(args))
    stdout_target = log_path.open("ab") if log_path else subprocess.DEVNULL
    stderr_target = log_path.open("ab") if log_path else subprocess.DEVNULL
    return subprocess.Popen(
        args,
        stdout=stdout_target,
        stderr=stderr_target,
        # New process group so we can shut the tunnel down cleanly.
        start_new_session=(os.name != "nt"),
    )


def extract_trycloudflare_url(log_path: Optional[Path], timeout: float = 60.0) -> Optional[str]:
    """Tail ``log_path`` until a ``*.trycloudflare.com`` URL appears."""
    if log_path is None or not log_path.exists():
        return None
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            data = log_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            data = ""
        match = _URL_RE.search(data)
        if match:
            return match.group(0)
        time.sleep(0.5)
    return None


# ---------------------------------------------------------------------------
#  CLI
# ---------------------------------------------------------------------------


def _build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cloudflare_tunnel",
        description="Expose ce_public_bridge.py over a Cloudflare quick tunnel.",
    )
    p.add_argument("--port", type=int, default=DEFAULT_PORT,
                   help=f"Local HTTP port to expose (default: {DEFAULT_PORT}).")
    p.add_argument("--host", default="127.0.0.1",
                   help="Local HTTP host the bridge is bound to (default: 127.0.0.1).")
    p.add_argument("--cloudflared", default=None,
                   help="Path to a cloudflared binary. If omitted, the script "
                        "downloads one into MCP_Server/cloudflared/.")
    p.add_argument("--named", default=None,
                   help="Run a pre-configured named tunnel instead of a quick tunnel.")
    p.add_argument("--log-file", default=None,
                   help="Path to write cloudflared stdout/stderr to (default: devnull). "
                        "Use this to inspect the live connection log without filling the terminal.")
    p.add_argument("--print-url", action="store_true",
                   help="Print the public trycloudflare.com URL to stdout when it appears.")
    return p


def main() -> int:
    args = _build_argparser().parse_args()
    try:
        binary = ensure_cloudflared(args.cloudflared)
    except RuntimeError as exc:
        _log(f"ERROR: {exc}")
        return 2

    local_url = f"http://{args.host}:{args.port}"
    log_path: Optional[Path] = None
    if args.log_file:
        log_path = Path(args.log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
    elif args.print_url:
        # When the user wants the URL printed we must capture cloudflared's
        # log so we can grep it. Default to a temp file.
        log_path = Path(tempfile.gettempdir()) / f"ce_cf_tunnel_{os.getpid()}.log"

    proc = run_tunnel(binary, local_url, named=args.named, log_path=log_path)

    if args.print_url and not args.named:
        _log("Waiting for cloudflared to publish a trycloudflare.com URL ...")
        url = extract_trycloudflare_url(log_path)
        if url is None:
            _log("Did not see a trycloudflare.com URL within the timeout. "
                 f"Check the log at {log_path}.")
        else:
            # Machine-readable line so other tooling can parse it.
            print(url, flush=True)
            print(f"PUBLIC_URL={url}", file=sys.stderr, flush=True)
    else:
        _log(f"Tunnel PID={proc.pid}; press Ctrl+C to stop.")
        _log(f"Local backend: {local_url}")

    try:
        return proc.wait()
    except KeyboardInterrupt:
        _log("Stopping tunnel ...")
        try:
            proc.terminate()
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
